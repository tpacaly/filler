/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/11/06 15:21:01 by tpacaly           #+#    #+#             */
/*   Updated: 2017/11/12 14:03:02 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "filler.h"

t_gene		set_point_sweet(t_gene a, int y, int x)
{
	t_point *tab0;
	int xx;

	xx = a.pt_m_ind;
	if(x == 0)
	{
		a.nbpoints_m++;
		return(a);
	}
	else
	{
		tab0 = a.points_m;
		tab0[xx].x = x;
		tab0[xx].y = y;
		a.pt_m_ind++;
	}
	return (a);
}

t_gene		set_point_nasty(t_gene a, int y, int x)
{
	t_point *tab0;
	int xx;

	xx = a.pt_m_ind;
	if(x == 0)
	{
		a.nbpoints_m_op++;
		return(a);
	}
	else
	{
		tab0 = a.points_m_op;
		tab0[xx].x = x;
		tab0[xx].y = y;
		a.pt_m_ind_op++;
	}
	return (a);
}

t_gene		take_points_map(t_gene a, char **tab)
{
	int y;
	int x;
	char player;
	char player0;

	x = 0;
	y = 0;
	player = (a.p == 1) ? 'O' : 'X';
	player0 = (a.p == 1) ? 'X' : 'O';
	while (y < a.y)
	{
		while(x < a.x)
		{
			if(tab[y][x] == player || tab[y][x] == player + 0x20)
				set_point_sweet(a, y, 0);
			else if(tab[y][x] == player0 || tab[y][x] == player0 + 0x20)
				set_point_nasty(a, y, 0);
			x++;
		}
		y++;
		x = 0;
	}
	return (a);
}

t_gene		fill_map(char **tab, t_gene a)
{
	int res;

	a = realloc_tab(a, tab); // alloue tableau 100*100 max et le remplis
	a = take_points_map(a, a.tabfinal); // prends les points sur le tableau
	res = count_points_p(tab, a.piecebeginline, a.piecex, a.piecey);
	if (!(a.points_p = (t_point *)malloc(sizeof(t_point *) * res + 1)))
		return (a);
	if (!(a.points_m = (t_point *)malloc(sizeof(t_point *) * a.nbpoints_m + 1)))
		return (a);
	if (!(a.points_m_op = (t_point *)malloc(sizeof(t_point *) * a.nbpoints_m_op + 1)))
		return (a);
	a.nbpoints_p = res;
	a = take_points_map(a, a.tabfinal); // on enregistre les points sur le tableau
	print_my_points(a);
	print_its_points(a);
	return (a);
}


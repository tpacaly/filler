/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/11/06 15:21:01 by tpacaly           #+#    #+#             */
/*   Updated: 2017/11/10 14:11:06 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "filler.h"

t_gene		set_point(t_gene a, int x, int y)
{
	int ind;

	ind = a.pt_p_ind;
	a.pt_p_ind += 1;
	a.points_p[ind].x = x;
	a.points_p[ind].y = y;
	return (a);
}

t_gene		set_point_m(t_gene a, int x, int y)
{
	int ind;
	ind = a.pt_m_ind;
	a.pt_m_ind += 1;
	a.points_m[ind].x = x;
	a.points_m[ind].y = y;
	return (a);
}

t_gene      set_point_op_m(t_gene a, int x, int y)
{   
	int ind;
	ind = a.pt_m_ind_op;
	a.pt_m_ind_op += 1;
	a.points_m_op[ind].x = x;
	a.points_m_op[ind].y = y;
	return (a);
}

t_gene		fill_map(char **tab, t_gene a)
{
	int LIMIT_Y = 3;
	int LIMIT_X = 4;
	int n;
	int x;
	int help_line;

	help_line = 0;
	n = a.y + LIMIT_Y;
	x = 0;
	while (help_line + LIMIT_Y < n)
	{
		while(tab[help_line + LIMIT_Y][x + LIMIT_X] == '.')
			x++;
		if (tab[help_line + LIMIT_Y][x + LIMIT_X] == 0)
		{
			x = 0;
			help_line++;
		}
		else if((a.p == 1 && (tab[help_line + LIMIT_Y][x + LIMIT_X] == 'o' || tab[help_line + LIMIT_Y][x + LIMIT_X] == 'O')) || (a.p == 2 && (tab[help_line + LIMIT_Y][x + LIMIT_X] == 'x' || tab[help_line + LIMIT_Y][x + LIMIT_X] == 'X')))
		{
			a = set_point_m(a, x, help_line);
			x++;
		}
		else if((a.p == 2 && (tab[help_line + LIMIT_Y][x + LIMIT_X] == 'o' || tab[help_line + LIMIT_Y][x + LIMIT_X] == 'O')) || (a.p == 1 && (tab[help_line + LIMIT_Y][x + LIMIT_X] == 'x' || tab[help_line + LIMIT_Y][x + LIMIT_X] == 'X')))
		{
			a = set_point_op_m(a, x, help_line);
			x++;
		}
		else
		{
			ft_dprintf(2, "err %s", &tab[help_line + LIMIT_Y][x + LIMIT_X]);
			x++;
		}
	}
	return (a);
}

t_gene		fill_piece(char **tab, t_gene a, int y)
{
	int line;
	int n;
	int x;
	int help_line;

	line = a.piecebeginline;
	help_line = line;
	n = 0;
	x = 0;
	while (tab[line++] != 0)
		n++;
	while (y < n)
	{
		while(tab[help_line + y][x] == '.')
			x++;
		if(tab[help_line + y][x] == 0)
		{
			y++;
			x = 0;
		}
		else
		{
			a = set_point(a, x, y);
			x++;
		}
	}
	return (a);
}

t_gene			count_points_map(char **tab, t_gene a)
{
	int y0;
	int x0;
	int x1;
	int x2;

	x0 = 4;
	y0 = 3;
	x1 = 0;
	x2 = 0;
	while (y0 < a.y + 3)
	{
		while (x0 < a.x + 4)
		{
			if (tab[y0][x0] == 'o' || tab[y0][x0] == 'O')
				x1++;
			else if (tab[y0][x0] == 'x' || tab[y0][x0] == 'X')
				x2++;
			x0++;
		}
		y0++;
		x0 = 4;
	}
	a.x1 = (a.p == 1) ? x1 : x2;
	a.x2 = (a.p == 1) ? x2 : x1;
	return (a);
}

int			count_points_p(char **tab, int line, int x, int y)
{
	int y0;
	int x0;
	int x1;

	x0 = 0;
	x1 = 0;
	y0 = 0;
	while(y0 < y)
	{
		while(x0 < x)
		{
			x1 = (tab[line + y0][x0] == '*') ? x1 + 1 : x1 ;
			x0++;
		}
		y0++;
		x0 = 0;
	}
	return (x1);
}

int			check_piece(char **tab, t_gene a, int x, int y)
{
	int		i;
	int		j;
	char	player;

	i = 0;
	j = 0;
	player = (a.p == 1) ? 'O' : 'X';
	while (i < a.nbpoints_p)
	{
		if (tab[y + a.points_p[i].y][x + a.points_p[i].x] == '.')
			i++;
		else if (tab[y + a.points_p[i].y][x + a.points_p[i].x] == player && j == 0)
		{
			j++;
			i++;
		}
		else
			return (0);
	}
	if (j == 1 && i == a.nbpoints_p)
		return (1);
	else
		return (0);
}

t_gene      place_piece(char **tab, t_gene a)
{
	int x;
	int y;
	char player;

	x = -a.w_max + 4;
	y = -a.n_max + 3;
	player = (a.p == 1) ? 'O' : 'X';
	while (y + (a.s_max - 1) < (a.y + 3))
	{
		while (x + (a.e_max - 1) < (a.x + 4))
		{
			if (check_piece(tab, a, x, y) == 1)
			{
				a.resy = x + a.w_max - 3;
				a.resx = y + a.s_max - 4;
				x++;
			}
			else
				x++;
		}
		y++;
		x = -a.w_max + 4;
	}
	return (a);
}

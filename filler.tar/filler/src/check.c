/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/11/06 15:21:01 by tpacaly           #+#    #+#             */
/*   Updated: 2017/11/09 12:39:36 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "filler.h"

t_gene		set_point(t_gene a, int x, int y)
{
	int ind;

	ind = a.ptind;
	a.ptind += 1;
	a.points[ind].x = x;
	a.points[ind].y = y;
	return(a);
}

t_gene		fill_piece(char **tab, t_gene a)
{
	int line;
	int n;
	int x;
	int help_line;

	line = a.piecebeginline;
	help_line = line;
	n = 0;
	x = n;
	while (tab[line++] != 0)
		n++;
	while (help_line != line)
	{
		while(tab[line][x] != '*' && tab[line][x] != '\0')
			x++;
		if(tab[line][x] == 0)
		{
			help_line++;
			x = 0;
		}
		else if(tab[line][x++] == '*')
			a = set_point(a, x - 1, line);
	}
	return (a);
}

int			count_points(char **tab, int line, int x, int y)
{
	int y0;
	int x0;
	int x1;

	x0 = 0;
	x1 = 0;
	y0 = 0;
	while(y0 < y)
	{
		while(x0 < x)
		{
			x1 = (tab[line + y0][x0] == '*') ? x1 + 1 : x1 ;
			x++;
		}
	}
	return (x1);
}
/*
int			ckeck_piece(char **tab, t_gene a)
{
	char player;

	player = (a.p == 1) ? 'O' : 'X' ;
}*/

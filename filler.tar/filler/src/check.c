/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/11/06 15:21:01 by tpacaly           #+#    #+#             */
/*   Updated: 2017/11/12 14:03:02 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "filler.h"

t_gene		set_point_sweet(t_gene a, int y, int x)
{
	t_point tab0;
	int xx;

	xx = a.pt_m_ind;
	if(x == 0)
	{
		a.nbpoints_m++;
		return(a);
	}
	else
	{
		tab0 = a.points_m;
		tab0[xx].x = x;
		tab0[xx].y = y;
		a.pt_m_ind++;
	}
	return (a);
}

t_gene		set_point_nasty(t_gene a, int y, int x)
{
	t_point tab0;
	int xx;

	xx = a.pt_m_ind;
	if(x == 0)
	{
		a.nbpoints_m_op++;
		return(a);
	}
	else
	{
		tab0 = a.points_m_op;
		tab0[xx].x = x;
		tab0[xx].y = y;
		a.pt_m_ind_op++;
	}
	return (a);
}

t_gene		take_points_map(t_gene a, char **tab)
{
	int y;
	int x;
	char player;

	x = 0;
	y = 0;
	player = (p == 1) : 'O' ? 'X';
	player0 = (p == 1) : 'X' ? 'O';
	while (y < a.y)
	{
		while(x < a.x)
		{
			if(tab[y][x] == player || tab[y][x] == player + 0x20)
				set_point_sweet(a, y, 0);
			else if(tab[y][x] == player0 || tab[y][x] == player0 + 0x20)
				set_point_nasty(a, y, 0);
			x++;
		}
		y++;
		x = 0;
	}
	return (a);
}

t_gene		fill_map(char **tab, t_gene a)
{
	int res;

	a = realloc_tab(a, tab); // alloue tableau 100*100 max et le remplis
	a = take_points_map(a, a.tabfinal); // prends les points sur le tableau
	res = count_points_p(tab, a.piecebeginline, a.piecex, a.piecey);
	if (!(a.points_p = (char **)malloc(sizeof(char *) * res + 1)))
		return (NULL);
	if (!(a.points_m = (char **)malloc(sizeof(char *) * a.nbpoints_m + 1)))
		return (NULL);
	if (!(a.points_m_op = (char **)malloc(sizeof(char *) * a.nbpoints_m_op + 1)))
		return (NULL);
	a.nbpoints_p = res;
	a = take_points_map(a, a.tabfinal); // on enregistre les points sur le tableau
	print_my_points(c);
	print_its_points(c);
	return (a);
}

t_gene		fill_piece(char **tab, t_gene a, int y)
{
	int line;
	int n;
	int x;
	int help_line;

	line = a.piecebeginline;
	help_line = line;
	n = 0;
	x = 0;
	while (tab[line++] != 0)
		n++;
	while (y < n)
	{
		while (tab[help_line + y][x] == '.')
			x++;
		if (tab[help_line + y][x] == 0)
		{
			y++;
			x = 0;
		}
		else
		{
			a = set_point(a, x, y);
			x++;
		}
	}
	return (a);
}

int			count_points_p(char **tab, int line, int x, int y)
{
	int y0;
	int x0;
	int x1;

	x0 = 0;
	x1 = 0;
	y0 = 0;
	ft_dprintf(2, "saulot %d %d\n", x, y);
	while (y0 < y && tab[line + y0] != NULL)
	{
		while (x0 < x)
		{
			x1 = (tab[line + y0][x0] == '*') ? x1 + 1 : x1;
			x0++;
		}
		ft_dprintf(2, "%d\n", y0);
		y0++;
		x0 = 0;
	}
	ft_dprintf(2, "finsaulot\n");
	return (x1);
}

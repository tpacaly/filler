/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/11/06 15:21:01 by tpacaly           #+#    #+#             */
/*   Updated: 2017/11/12 14:03:02 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "filler.h"

t_gene		fill_map(char **tab, t_gene a)
{
	int n;
	int x;
	int help_line;

	help_line = 0;
	n = a.y + LIMITY;
	x = 0;
	while (help_line + LIMITY < n)
	{
		while(tab[help_line + LIMITY][x + LIMITX] == '.')
			x++;
		if (tab[help_line + LIMITY][x + LIMITX] == 0)
		{
			x = 0;
			help_line++;
		}
		else if((a.p == 1 && (tab[help_line + LIMITY][x + LIMITX] == 'o' || tab[help_line + LIMITY][x + LIMITX] == 'O')) || (a.p == 2 && (tab[help_line + LIMITY][x + LIMITX] == 'x' || tab[help_line + LIMITY][x + LIMITX] == 'X')))
		{
			a = set_point_m(a, x, help_line);
			x++;
		}
		else if((a.p == 2 && (tab[help_line + LIMITY][x + LIMITX] == 'o' || tab[help_line + LIMITY][x + LIMITX] == 'O')) || (a.p == 1 && (tab[help_line + LIMITY][x + LIMITX] == 'x' || tab[help_line + LIMITY][x + LIMITX] == 'X')))
		{
			a = set_point_op_m(a, x, help_line);
			x++;
		}
		else
		{
			ft_dprintf(2, "err %s", &tab[help_line + LIMITY][x + LIMITX]);
			x++;
		}
	}
	return (a);
}

t_gene		fill_piece(char **tab, t_gene a, int y)
{
	int line;
	int n;
	int x;
	int help_line;

	line = a.piecebeginline;
	help_line = line;
	n = 0;
	x = 0;
	while (tab[line++] != 0)
		n++;
	while (y < n)
	{
		while(tab[help_line + y][x] == '.')
			x++;
		if(tab[help_line + y][x] == 0)
		{
			y++;
			x = 0;
		}
		else
		{
			a = set_point(a, x, y);
			x++;
		}
	}
	return (a);
}

t_gene		count_points_map(char **tab, t_gene a)
{
	int y0;
	int x0;
	int x1;
	int x2;

	x0 = 4;
	y0 = 3;
	x1 = 0;
	x2 = 0;
	while (y0 < a.y + 3)
	{
		while (x0 < a.x + 4)
		{
			if (tab[y0][x0] == 'o' || tab[y0][x0] == 'O')
				x1++;
			else if (tab[y0][x0] == 'x' || tab[y0][x0] == 'X')
				x2++;
			x0++;
		}
		y0++;
		x0 = 4;
	}
	a.x1 = (a.p == 1) ? x1 : x2;
	a.x2 = (a.p == 1) ? x2 : x1;
	return (a);
}

int			count_points_p(char **tab, int line, int x, int y)
{
	int y0;
	int x0;
	int x1;

	x0 = 0;
	x1 = 0;
	y0 = 0;
	ft_dprintf(2, "saulot %d %d\n", x, y);
	while(y0 < y || tab[line + y0] != NULL)
	{
		while(x0 < x)
		{
			x1 = (tab[line + y0][x0] == '*') ? x1 + 1 : x1;
			x0++;
		}
		ft_dprintf(2, "%d\n", y0);
		y0++;
		x0 = 0;
	}
	ft_dprintf(2, "finsaulot\n");
	return (x1);
}

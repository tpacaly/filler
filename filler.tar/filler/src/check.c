/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/11/06 15:21:01 by tpacaly           #+#    #+#             */
/*   Updated: 2017/11/09 19:49:20 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "filler.h"

t_gene		set_point(t_gene a, int x, int y)
{
	int ind;

	ind = a.ptind;
	a.ptind += 1;
	a.points[ind].x = x;
	a.points[ind].y = y;
	return(a);
}

t_gene		fill_piece(char **tab, t_gene a, int y)
{
	int line;
	int n;
	int x;
	int help_line;

	line = a.piecebeginline;
	help_line = line;
	n = 0;
	x = 0;
	while (tab[line++] != 0)
		n++;
	while (y < n)
	{
		while(tab[help_line + y][x] == '.')
			x++;
		if(tab[help_line + y][x] == 0)
		{
			y++;
			x = 0;
		}
		else
		{
			a = set_point(a, x, y);
			x++;
		}
	}
	return (a);
}

int			count_points(char **tab, int line, int x, int y)
{
	int y0;
	int x0;
	int x1;

	x0 = 0;
	x1 = 0;
	y0 = 0;
	while(y0 < y)
	{
		while(x0 < x)
		{
			x1 = (tab[line + y0][x0] == '*') ? x1 + 1 : x1 ;
			x0++;
		}
		y0++;
		x0 = 0;
	}
	return (x1);
}

int			check_piece(char **tab, t_gene a, int x, int y)
{
	int		i;
	int		j;
	char	player;

	i = 0;
	j = 0;
	player = (a.p == 1) ? 'O' : 'X';
	while (i < a.nbpoints)
	{
		if (tab[y + a.points[i].y][x + a.points[i].x] == '.')
			i++;
		else if (tab[y + a.points[i].y][x + a.points[i].x] == player && j == 0)
		{
			j++;
			i++;
		}
		else
			return (0);
	}
	if (j == 1 && i == a.nbpoints)
		return (1);
	else
		return (0);
}

t_gene      place_piece(char **tab, t_gene a)
{
	int x;
	int y;
	char player;

	x = -a.w_max + 4;
	y = -a.n_max + 4 ;
	player = (a.p == 1) ? 'O' : 'X';
	while (y + (a.s_max - 1) < (a.y + 4))
	{
		while (x + (a.e_max - 1) < (a.x + 4))
		{
			if (check_piece(tab, a, x, y) == 1)
			{
				a.resx = x + a.w_max - 4;
				a.resy = y + a.s_max - 4;
				x++;
			}
			else
				x++;
		}
		y++;
		x = -a.w_max + 4;
	}
	return (a);
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parser.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/31 19:24:51 by tpacaly           #+#    #+#             */
/*   Updated: 2017/10/31 19:27:17 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "filler.h"

t_gene		take_piece(char **tab, t_gene a)
{
	int y;
	int i;

	y = a.nblines - 1;
	i = 6;
	while(ft_strncmp("Piece ", tab[y], 6) != 0 && tab[y] != 0)
		y--;
	if(tab[y] == 0)
		a.error = 1;
	else
	{
		a.piecey = ft_atoi(&tab[y][i]);
		while(tab[y][i] < 0x3a && tab[y][i] > 0x2f)
			i++;
		a.piecex = ft_atoi(&tab[y][++i]);
	}
	a.piecebeginline = y;
	return(a);
}

t_gene		find_params(char **tab, t_gene a)
{
	int i;

	i = 8;
	a.error = 0;
	if (ft_strncmp("$$$ exec p1", tab[0], 11) == 0)
		a.p = 1;
	else if (ft_strncmp("$$$ exec p2", tab[0], 11) == 0)
		a.p = 2;
	else
		a.error = 1;
	if (ft_strncmp("Plateau ", tab[1], 8) != 0)
		a.error = 1;
	else
	{
		a.y = ft_atoi(&tab[1][i]);
		while(tab[1][i] < 0x3a && tab[1][i] > 0x2f)
			i++;
		a.x = ft_atoi(&tab[1][++i]);
	}
	return(a);
}
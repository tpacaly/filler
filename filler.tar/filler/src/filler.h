/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   filler.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/31 18:49:30 by tpacaly           #+#    #+#             */
/*   Updated: 2017/11/10 14:18:08 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FILLER_H
# define FILLER_H
#include "../libft/sources/ft_printf.h"

typedef struct		s_point
{
	int x;
	int y;
}					t_point;

typedef struct		s_gene
{
	int				p;
	int				x;
	int				y;
	int				error;
	int				nblines;
	int				piecex;
	int				piecey;
	int				piecebeginline;
	char			**piece;
	int				n_max;
	int				s_max;
	int				w_max;
	int				e_max;
	int				realpx;
	int				realpy;
	int				nbpoints_p;
	int				nbpoints_m;
	int				nbpoints_m_op;
	t_point			*points_p;
	t_point			*points_m;
	t_point			*points_m_op;
	int				pt_m_ind;
	int				pt_p_ind;
	int				pt_m_ind_op;
	int				resx;
	int				resy;
	int				x1;
	int				x2;
}					t_gene;

void				print_my_points(t_gene c);
void				print_it_points(t_gene c);
t_gene				find_params(char **tab, t_gene a);
char				**ft_malloc_tabtab(char **tab, char *str);
t_gene				take_piece(char **tab, t_gene a);
t_gene				get_limits_piece(char **tab, t_gene a);
t_gene				take_limits(char **tab, t_gene a);
t_gene				fill_piece(char **tab, t_gene a, int y);
t_gene				fill_map(char **tab, t_gene a);
int					count_points_p(char **tab, int line, int x, int y);
int					lastline(char **tab);
t_gene				place_piece(char **tab, t_gene a);
t_gene				count_points_map(char **tab, t_gene a);

#endif

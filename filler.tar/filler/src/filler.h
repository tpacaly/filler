/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   filler.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/31 18:49:30 by tpacaly           #+#    #+#             */
/*   Updated: 2017/11/01 21:27:28 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FILLER_H
# define FILLER_H
# include "../libft/sources/ft_printf.h"

typedef struct		s_gene
{
	int				p;
	int				x;
	int				y;
	int				error;
	int				nblines;
	int				piecex;
	int				piecey;
	int				piecebeginline;
	char			**piece;
}					t_gene;

t_gene				find_params(char **tab, t_gene a);
char				**ft_malloc_tabtab(char **tab, char *str);
t_gene				take_piece(char **tab, t_gene a);

#endif

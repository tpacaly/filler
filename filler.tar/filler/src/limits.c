/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   limits.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/11/08 10:44:00 by tpacaly           #+#    #+#             */
/*   Updated: 2017/11/10 14:55:57 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "filler.h"

int				take_east_limits(char **tab, t_gene a)
{
	int x;
	int line;
	int h_line;
	int g;

	line = a.piecebeginline;
	g = ft_strlen(tab[line]) - 1;
	h_line = line;
	x = 0;
	while (tab[line][g] == '.' || tab[line] == NULL)
	{
		if (tab[line] == NULL)
		{
			g--;
			line = h_line;
			x++;
		}
		else
			line++;
	}
	return (x);
}

int				take_west_limits(char **tab, t_gene a)
{
	int x;
	int line;
	int h_line;
	int g;

	g = 0;
	line = a.piecebeginline;
	h_line = line;
	x = 0;
	while (tab[line][g] == '.' || tab[line] == NULL)
	{
		if (tab[line] == NULL)
		{
			g++;
			line = h_line;
			x++;
		}
		else
			line++;
	}
	return (x);
}

int				take_north_limits(char **tab, t_gene a)
{
	int x;
	int line;
	int g;

	x = 0;
	line = a.piecebeginline;
	g = 0;
	while (tab[line][g] == '.' || tab[line][g] == '\0')
	{
		if (tab[line][g] == '\0')
		{
			g = 0;
			x++;
			line++;
		}
		else
			g++;
	}
	return (x);
}

int				take_south_limits(char **tab, t_gene a)
{
	int x;
	int line;
	int g;

	x = 0;
	g = 0;
	line = a.piecebeginline;
	while (tab[line] != NULL)
	{
		if (tab[line][g] == 0)
		{
			g = 0;
			x++;
			line++;
		}
		else
		{
			x = (tab[line][g] != '.') ? 0 : x;
			g++;
		}
	}
	return (x);
}

t_gene			take_limits(char **tab, t_gene a)
{
	ft_dprintf(2, "ft_segnorth\n");
	a.n_max = take_north_limits(tab, a);
	ft_dprintf(2, "ft_segwest\n");
	a.w_max = take_west_limits(tab, a);
	ft_dprintf(2, "ft_segeast\n");
	a.e_max = take_east_limits(tab, a);
	ft_dprintf(2, "ft_segsouth\n");
	a.s_max = take_south_limits(tab, a);
	a.realpx = a.piecex - a.w_max - a.e_max;
	a.realpy = a.piecey - a.n_max - a.s_max;
	return (a);
}

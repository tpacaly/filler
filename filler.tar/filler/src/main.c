/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/31 18:40:53 by tpacaly           #+#    #+#             */
/*   Updated: 2017/11/09 14:32:44 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "filler.h"

char		*resolve(char **tab, int i)
{
	t_gene	*a;
	t_gene	c;
	t_point	*points;

	if ((a = malloc(sizeof(t_gene*) * 1)) == 0)
		exit(1);
	c = *a;
	ft_bzero(&c, sizeof(t_gene));
	c.nblines = i;
	c = find_params(tab, c);
	c = take_piece(tab, c);
	c = take_limits(tab, c);
	c.nbpoints = count_points(tab, c.piecebeginline, c.piecex, c.piecey);
	ft_dprintf(2, "cntpts %d\n", c.nbpoints);
	if (c.error == 1)
		exit(1);
	if ((points = malloc(sizeof(t_point*) * c.nbpoints)) == 0)
		exit(1);
	c.points = points;
	c.ptind = 0;
	c = fill_piece(tab, c, 0);
//	ft_memdel((void**)&points);
//	ft_memdel((void**)&a);
	c = place_piece(tab, c);
	ft_dprintf(2, "%d %d\n", c.resx, c.resy);
	return(NULL);
//	return (transintchar(c));
}

int			main(int ac, char **av)
{
	char	**tab;
	char	*line;
	char	*sortie;
	int		i;

	i = 0;
	(void)ac;
	(void)av;
	while (get_next_line(0, &line) == 1)
		tab = ft_malloc_tabtab(tab, line);
	while (tab[i] != NULL)
		i++;
	sortie = resolve(tab, i);
	i = 0;
	if (sortie != NULL)
		write(1, sortie, ft_strlen(sortie));
	return (0);
}

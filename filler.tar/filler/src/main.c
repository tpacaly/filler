/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/31 18:40:53 by tpacaly           #+#    #+#             */
/*   Updated: 2017/11/12 13:54:20 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "filler.h"
/*
t_gene		take_points(char **tab, t_gene c)
{
	c = take_piece(tab, c);
	ft_dprintf(2, "ft_seg000\n");
	c = take_limits(tab, c);
	ft_dprintf(2, "ft_seg00");
	c.nbpoints_p = count_points_p(tab, c.piecebeginline, c.piecex, c.piecey);
	ft_dprintf(2, "ft_seg0\n");
	c = count_points_map(tab, c);
	if (c.error == 1)
		exit(1);
	if ((c.points_p = malloc(sizeof(t_point*) * c.nbpoints_p + 1)) == 0)
		exit(1);
	if ((c.points_m = malloc(sizeof(t_point*) * c.nbpoints_m + 1)) == 0)
		exit(1);
	if ((c.points_m_op = malloc(sizeof(t_point*) * c.nbpoints_m_op + 1)) == 0)
		exit(1);
	ft_dprintf(2, "ft_seg\n");
	c = fill_piece(tab, c, 0);
	c = fill_map(tab, c);
	return (c);
}
*/

void	ft_free(char **tab)
{
	int i;

	i = 0;
	while(tab[i])
	{
		ft_strdel(&tab[i]);
		i++
	}
	free(tab);
	tab = NULL;
}

int			resolve(char **tab, int i)
{
	t_gene	*a;
	t_gene	c;

	if ((a = malloc(sizeof(t_gene*) * 1)) == 0)
		exit(1);
	c = *a;
	ft_bzero(&c, sizeof(t_gene));
	c.nblines = i;
	c = find_params(tab, c);
	ft_free(tab);
//	c = take_points(tab, c);
	//	ft_memdel((void**)&points);
	//	ft_memdel((void**)&a);
//	ft_free(a.tabfinal);
	return(ft_dprintf(1, "%d %d", c.resy, c.resx));
}

int			main(int ac, char **av)
{
	char	**tab;
	char	*line;
	int		i;

	i = 0;
	(void)ac;
	(void)av;
	while (get_next_line(0, &line) == 1)
		tab = ft_malloc_tabtab(tab, line);
	while (tab[i] != NULL)
		i++;
	resolve(tab, i);
	return (0);
}

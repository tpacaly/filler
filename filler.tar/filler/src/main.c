/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/31 18:40:53 by tpacaly           #+#    #+#             */
/*   Updated: 2017/11/12 13:54:20 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "filler.h"

void	ft_free(char **tab)
{
	int i;

	i = 0;
	while(tab[i])
	{
		ft_memdel((void**)&tab[i]);
		i++;
	}
	free(tab);
	tab = NULL;
}

int			resolve(char **tab, int i)
{
	t_gene	*a;
	t_gene	c;

	if ((a = malloc(sizeof(t_gene*) * 1)) == 0)
		exit(1);
	c = *a;
	ft_bzero(&c, sizeof(t_gene));
	c.nblines = i;
	c = find_params(tab, c);
	c = take_piece(tab, c);
	c = fill_map(tab, c);
//	ft_free(tab);
	//	ft_memdel((void**)&points);
	//	ft_memdel((void**)&a);
//	ft_free(a.tabfinal);
	return(ft_dprintf(1, "%d %d", c.resy, c.resx));
}

int			main(int ac, char **av)
{
	char	**tab;
	char	*line;
	int		i;

	i = 0;
	(void)ac;
	(void)av;
	while (get_next_line(0, &line) == 1)
		tab = ft_malloc_tabtab(tab, line);
	while (tab[i] != NULL)
		i++;
	resolve(tab, i);
	return (0);
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/31 18:40:53 by tpacaly           #+#    #+#             */
/*   Updated: 2017/10/31 19:46:22 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "filler.h"

static void	ft_free_tab(char **tab)
{
	int i;

	i = -1;
	while (tab[++i])
		ft_strdel(&tab[i]);
	ft_strdel(&tab[i]);
	free(tab);
	tab = NULL;
}

static char	**ft_create(int size_y, char **tab, char *str)
{
	if (!(tab = (char **)malloc(sizeof(char *) * size_y + 1)))
		return (NULL);
	tab[0] = ft_strdup(str);
	tab[1] = 0;
	return (tab);
}

static char	**ft_new(int size_y, char **tab, char *str)
{
	char	**t;
	int		i;

	i = -1;
	if (!(t = (char **)malloc(sizeof(char *) * size_y + 1)))
		return (NULL);
	t[size_y] = NULL;
	while (tab[++i])
		t[i] = ft_strdup(tab[i]);
	t[i] = ft_strdup(str);
	ft_free_tab(tab);
	if (!(tab = (char **)malloc(sizeof(char *) * size_y + 1)))
		return (NULL);
	tab[size_y] = NULL;
	i = -1;
	while (t[++i])
		tab[i] = ft_strdup(t[i]);
	ft_free_tab(t);
	return (tab);
}

char		**ft_malloc_tabtab(char **tab, char *str)
{
	int size_y;

	if (!str)
		return (NULL);
	if (!tab)
	{
		if ((tab = ft_create(1, tab, str)) == NULL)
			return (NULL);
	}
	else
	{
		size_y = 0;
		while (tab[size_y])
			size_y++;
		if ((tab = ft_new(size_y + 1, tab, str)) == NULL)
			return (NULL);
	}
	return (tab);
}

int main(int ac, char **av)
{
//	char **tab;
//	char *line;
	char *sortie;

	(void)ac;
	(void)av;
//	while(get_next_line(0, &line) == 1)
//		tab = ft_malloc_tabtab(tab, line);
//	while(tab[i] != NULL)
//		ft_dprintf(2, ">>> %s\n", tab[i++]);
//	i = 0;
//	while(tab[i] != NULL)
//		ft_strdel(&tab[i]);
	write(1, sortie, ft_strlen(sortie));
	return (0);
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/31 18:40:53 by tpacaly           #+#    #+#             */
/*   Updated: 2017/11/01 23:51:26 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "filler.h"

/*char		**alloc_and_draw_piece(char **tab, t_gene a)
{

}*/

char		*resolve(char **tab, int i)
{
	char	*b = 0;
	t_gene	*a;
	t_gene	c;

	if ((a = malloc(sizeof(t_gene*) * 1)) == 0)
		exit(1);
	ft_bzero(a, sizeof(t_gene));
	c = *a;
	c.nblines = i;
	c = find_params(tab, c);
	c = take_piece(tab, c);
	c = get_limits_piece(tab, c);
	if (a->error == 1)
		exit(1);
//	c.piece = alloc_and_draw_piece(tab, c);
//	if (a->error == 1)
//		exit(1);
//	c = resolve_2(tab, c);
//	ft_dprintf(2, "%d; x = %d; y = %d; px = %d; py= %d %s\n", c.p, c.x, c.y, c.piecex, c.piecey, tab[c.piecebeginline]);
	//if(premiercoup) b = (a.p == 1) ? "2 8" : "14 12"
	return(b);
}

int			main(int ac, char **av)
{
	char	**tab;
	char	*line;
	char	*sortie;
	int		i;

	i = 0;
	(void)ac;
	(void)av;
	while(get_next_line(0, &line) == 1)
		tab = ft_malloc_tabtab(tab, line);
	while(tab[i] != 0)
		i++;
	sortie = resolve(tab, i);
	i = 0;
	while(tab[i] != 0)
		ft_strdel(&tab[i]);
	if (sortie != NULL)
		write(1, sortie, ft_strlen(sortie));
	return (0);
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   piece.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/11/28 10:37:15 by tpacaly           #+#    #+#             */
/*   Updated: 2017/11/28 10:37:22 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "filler.h"

t_gene		fill_piece(char **tab, t_gene a, int y)
{
	int line;
	int n;
	int x;
	int help_line;

	line = a.piecebeginline;
	help_line = line;
	n = 0;
	x = 0;
	while (tab[line++] != 0)
		n++;
	while (y < n)
	{
		while (tab[help_line + y][x] == '.')
			x++;
		if (tab[help_line + y][x] == 0)
		{
			y++;
			x = 0;
		}
		else
		{
			a = set_point(a, x, y);
			x++;
		}
	}
	return (a);
}

int			count_points_p(char **tab, int line, int x, int y)
{
	int y0;
	int x0;
	int x1;

	x0 = 0;
	x1 = 0;
	y0 = 0;
	ft_dprintf(2, "saulot %d %d\n", x, y);
	while (y0 < y && tab[line + y0] != NULL)
	{
		while (x0 < x)
		{
			x1 = (tab[line + y0][x0] == '*') ? x1 + 1 : x1;
			x0++;
		}
		ft_dprintf(2, "%d\n", y0);
		y0++;
		x0 = 0;
	}
	ft_dprintf(2, "finsaulot\n");
	return (x1);
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils2.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/11/09 14:14:20 by tpacaly           #+#    #+#             */
/*   Updated: 2017/11/10 14:19:50 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "filler.h"

void		print_my_points(t_gene c)
{
	int i;

	i = 0;
	while(i < c.x1)
	{
		ft_dprintf(2, "%d %d %d\n", i, c.points_m[i].x, c.points_m[i].y);
		i++;
	}
}

void		print_it_points(t_gene c)
{
	int i;

	i = 0;
	while(i < c.x2)
	{
		ft_dprintf(2, "%d %d %d\n", i, c.points_m_op[i].x, c.points_m_op[i].y);
		i++;
	}
}

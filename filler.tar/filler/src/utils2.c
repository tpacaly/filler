/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils2.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/11/09 14:14:20 by tpacaly           #+#    #+#             */
/*   Updated: 2017/11/10 14:19:50 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "filler.h"

t_gene		set_point(t_gene a, int x, int y)
{
	int ind;

	ind = a.pt_p_ind;
	a.pt_p_ind += 1;
	a.points_p[ind].x = x;
	a.points_p[ind].y = y;
	return (a);
}

t_gene		set_point_m(t_gene a, int x, int y)
{
	int ind;

	ind = a.pt_m_ind;
	a.pt_m_ind += 1;
	a.points_m[ind].x = x;
	a.points_m[ind].y = y;
	return (a);
}

t_gene		set_point_op_m(t_gene a, int x, int y)
{
	int ind;

	ind = a.pt_m_ind_op;
	a.pt_m_ind_op += 1;
	a.points_m_op[ind].x = x;
	a.points_m_op[ind].y = y;
	return (a);
}

t_gene				realloc_tab(t_gene a, char **tab)
{
	char **tab0;
	int i;
	int j;

	if (!(tab0 = (char **)malloc(sizeof(char *) * a.y + 1)))
		return (a);
	tab0[a.y] = NULL;
	tab[a.y+3] = NULL;
	i = 0;
	j = 3;
	while (j < a.y + 3)
	{
		tab0[i] = ft_strdup(&tab[j][4]);
		i++;
		j++;
	}
//	ft_free(tab0);
//	ft_free(tab);
//	while(1){}
	a.tabfinal = tab0;
	return (a);
}

void		print_my_points(t_gene c)
{
	int i;

	i = 0;
	while (i < c.nbpoints_m)
	{
		ft_dprintf(2, "%d %d/n", i, c.points_m[i].x, c.points_m[i].y);
		i++;
	}
}

void		print_its_points(t_gene c)
{
	int i;

	i = 0;
	while (i < c.nbpoints_m_op)
	{
		ft_dprintf(2, "%d %d/n", i, c.points_m_op[i].x, c.points_m_op[i].y);
		i++;
	}
}

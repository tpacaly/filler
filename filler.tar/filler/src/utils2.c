/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils2.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/11/09 14:14:20 by tpacaly           #+#    #+#             */
/*   Updated: 2017/11/10 14:19:50 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "filler.h"

t_gene		set_point(t_gene a, int x, int y)
{
	int ind;

	ind = a.pt_p_ind;
	a.pt_p_ind += 1;
	a.points_p[ind].x = x;
	a.points_p[ind].y = y;
	return (a);
}

t_gene		set_point_m(t_gene a, int x, int y)
{
	int ind;

	ind = a.pt_m_ind;
	a.pt_m_ind += 1;
	a.points_m[ind].x = x;
	a.points_m[ind].y = y;
	return (a);
}

t_gene		set_point_op_m(t_gene a, int x, int y)
{
	int ind;

	ind = a.pt_m_ind_op;
	a.pt_m_ind_op += 1;
	a.points_m_op[ind].x = x;
	a.points_m_op[ind].y = y;
	return (a);
}

void		print_my_points(t_gene c)
{
	int i;

	i = 0;
	while (i < c.x1)
	{
		ft_dprintf(2, "%d %d %d\n", i, c.points_m[i].x, c.points_m[i].y);
		i++;
	}
}

void		print_it_points(t_gene c)
{
	int i;

	i = 0;
	while (i < c.x2)
	{
		ft_dprintf(2, "%d %d %d\n", i, c.points_m_op[i].x, c.points_m_op[i].y);
		i++;
	}
}

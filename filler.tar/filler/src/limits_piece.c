/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   limits_piece.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/11/03 18:57:16 by tpacaly           #+#    #+#             */
/*   Updated: 2017/11/03 18:57:25 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "filler.h"

int			limit_piece_n(char **tab, int line)
{
	int u;
	int w;

	u = 0;
	w = 0;
	while (tab[line][u] == '\0' || tab[line][u] == '.')
	{
		u = (tab[line][u] == '.') ? u + 1 : u ;
		if(tab[line][u] == '\0')
		{
			u = 0;
			w++;
			line++;
		}
	}
	return(w);
}

int			limit_piece_s(char **tab, int ymax, int line)
{
	int u;
	int w;

	u = 0;
	w = 0;
	ymax += line - 2;
	while (tab[ymax][u] == '\0' || tab[ymax][u] == '.')
	{
		u = (tab[ymax][u] == '.') ? u + 1 : u ;
		if(tab[ymax][u] == '\0')
		{
			u = 0;
			w++;
			ymax--;
		}
	}
	return(w);
}
int			limit_piece_w(char **tab, int ymax, int line)
{
	int u;
	int w;
	int helpx;

	u = 0;
	helpx = line;
	w = 0;
	while (tab[line][w] == '.')
	{
		line = (tab[line][w] == '.') ? line + 1 : line ;
		if(line == helpx + ymax)
		{
			line = helpx;
			w++;
		}
	}
	//w = (w == 0) ? w : w - 1;
	return(w);
}

/*
int			limit_piece_e(char **tab, int xmax, int ymax, int line)
{
	
}*/

t_gene		get_limits_piece(char **tab, t_gene a)
{
	a.n_max = limit_piece_n(tab, a.piecebeginline);
	a.s_max = limit_piece_s(tab, a.piecey, a.piecebeginline);
	a.w_max = limit_piece_w(tab, a.piecey, a.piecebeginline);
/*	a.e_max = limit_piece_e(tab, a.piecex, a.piecey, a.piecebeginline);
*/	ft_dprintf(2, "%d %d %d\n", a.n_max, a.s_max, a.w_max);
	return(a);
}
/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   place_piece.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/11/27 12:14:45 by tpacaly           #+#    #+#             */
/*   Updated: 2017/11/27 12:14:56 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "filler.h"


int			check_piece_contact(char **tab, t_gene a, int x, int y)
{
	int		i;
	int		j;
	char	player;

	i = 0;
	j = 0;
	player = (a.p == 1) ? 'O' : 'X';
	while (i < a.nbpoints_p)
	{
		if (tab[y + a.points_p[i].y][x + a.points_p[i].x] == '.')
			i++;
		else if (tab[y + a.points_p[i].y][x + a.points_p[i].x] != player && j == 0)
		{
			j++;
			i++;
		}
		else
			return (0);
	}
	if (j == 1 && i == a.nbpoints_p)
		return (1);
	else
		return (0);
}

int			check_piece(char **tab, t_gene a, int x, int y)
{
	int		i;
	int		j;
	char	player;

	i = 0;
	j = 0;
	player = (a.p == 1) ? 'O' : 'X';
	while (i < a.nbpoints_p)
	{
		if (tab[y + a.points_p[i].y][x + a.points_p[i].x] == '.')
			i++;
		else if (tab[y + a.points_p[i].y][x + a.points_p[i].x] == player && j == 0)
		{
			j++;
			i++;
		}
		else
			return (0);
	}
	if (j == 1 && i == a.nbpoints_p)
		return (1);
	else
		return (0);
}

t_gene		place_piece_0(char **tab, t_gene a)
{

}

t_gene		place_piece_1(char **tab, t_gene a)
{
	
}

t_gene		place_piece(char **tab, t_gene a)
{
	int x;
	int y;
	char player;

	x = -a.w_max + LIMITX;
	y = -a.n_max + LIMITY;
	a.protocol = 0;
	a.resultx = 0;
	a.resulty = 0;
	if(place_piece_0() == 0)
	{
		if(place_piece_1() == 0)
			return(a);
	}
	player = (a.p == 1) ? 'O' : 'X';
	while (y + (a.s_max - 1) < (a.y + LIMITY))
	{
		while (x + (a.e_max - 1) < (a.x + LIMITX))
		{
			if (check_piece(tab, a, x, y) == 1)
			{
				a.resx = x + a.w_max - LIMITY;
				a.resy = y + a.s_max - LIMITX;
				x++;
			}
			else
				x++;
		}
		y++;
		x = -a.w_max + LIMITX;
	}
	return (a);
}

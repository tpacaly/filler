/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   place_piece.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/11/27 12:14:45 by tpacaly           #+#    #+#             */
/*   Updated: 2017/11/27 12:14:56 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "filler.h"


int			check_piece_contact(char **tab, t_gene a, int x, int y)
{
	int		i;
	int		j;
	char	player;

	i = 0;
	j = 0;
	player = (a.p == 1) ? 'O' : 'X';
	while (i < a.nbpoints_p)
	{
		if (tab[y + a.points_p[i].y][x + a.points_p[i].x] == '.')
			i++;
		else if (tab[y + a.points_p[i].y][x + a.points_p[i].x] != player && j == 0)
		{
			j++;
			i++;
		}
		else
			return (0);
	}
	if (j == 1 && i == a.nbpoints_p)
		return (1);
	else
		return (0);
}

int			check_piece(char **tab, t_gene a, int x, int y)
{
	int		i;
	int		j;
	char	player;

	i = 0;
	j = 0;
	player = (a.p == 1) ? 'O' : 'X';
	while (i < a.nbpoints_p)
	{
		if (tab[y + a.points_p[i].y][x + a.points_p[i].x] == '.')
			i++;
		else if (tab[y + a.points_p[i].y][x + a.points_p[i].x] == player && j == 0)
		{
			j++;
			i++;
		}
		else
			return (0);
	}
	if (j == 1 && i == a.nbpoints_p)
		return (1);
	else
		return (0);
}
